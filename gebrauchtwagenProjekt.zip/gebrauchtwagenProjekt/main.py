
from autoFunctions import main
main()
